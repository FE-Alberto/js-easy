// let {readFile} = require('./utils/fsPromise');
// readFile(`./static/img/title.png`).then(result => {
//     console.log(result);
// }).catch(error => {
//     console.log(error);
// });

// let url=require('url');
// console.log(url.parse('/temp?name=xxx&age=25', true));

// let qs = require('qs');
// console.log(qs.parse('name=xxx&age=25'));