let B = require('./B');
console.log(B.avg(12, 23, 34, 45, 56, 67, 78, 89));

console.log(__filename);