let http = require('http');
http.createServer(function(req,res){
    res.end('zf2')
}).listen(8000);