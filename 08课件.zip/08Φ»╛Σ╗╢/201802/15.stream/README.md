## 可读流 flowing
## 可写流 fs.createWriteStream()
## pipe

> 对文件操作,sokcet http