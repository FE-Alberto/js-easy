process.argv.slice(2).forEach(function(arg){
    process.stdout.write(arg);
})  