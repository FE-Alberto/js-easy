console.log('加载');
module.exports = function(){
    
}




/*
(functuon(exports,require,module,__dirname,__filename){
    console.log('加载')
    module.exports = 'zfpx';
    
})({},req,{filename,exports:{}})
*/