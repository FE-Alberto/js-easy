let b = require('./b.js');
// b代表的是b模块的module.exports对象
console.log(b);