## 安装create-react-app
```
npm install create-react-app -g
create-react-app project-filename
```


## react 有react和react-dom


## react和vue
- react基于jsx语法 facebook  
- vue基于模板 
