import './code2/6.lifeCycle';


