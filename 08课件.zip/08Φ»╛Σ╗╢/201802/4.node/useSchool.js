let school = require('./school');
console.log(school)