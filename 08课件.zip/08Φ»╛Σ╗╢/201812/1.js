function Router(){
    let xxx = {name:'zfpx'};
    return xxx;
}

let r1 = Router();
let r2 = new Router();
console.log(r1);
console.log(r2);

