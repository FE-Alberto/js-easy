
let a = 10
let b = a+10;
