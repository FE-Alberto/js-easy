console.log(16**2*8);//2048
console.log(2**16-1);//65535
console.log(0x4E07.toString(10));
//19975
//16
//xxxxxxxxxxxxxxxx
//1111111111111111