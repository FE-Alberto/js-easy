let argv = require('yargs').argv;
console.log(argv.name);
