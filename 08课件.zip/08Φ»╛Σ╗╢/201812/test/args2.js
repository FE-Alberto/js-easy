let argv = require('yargs').alias('n', 'name')
    .argv;
console.log(argv);
