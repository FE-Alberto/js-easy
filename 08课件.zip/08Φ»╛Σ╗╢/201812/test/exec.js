#!/usr/bin/env node
console.log('hello', process.argv[2]);
