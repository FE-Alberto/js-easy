let e = require('./1.exports');
e();