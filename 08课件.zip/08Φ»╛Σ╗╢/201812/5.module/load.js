console.log(module.loaded);
//require import的区别 什么情况下使用
