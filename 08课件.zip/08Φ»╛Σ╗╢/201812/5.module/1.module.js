/* 0. 命名空间
 * 1. 闭包 自执行函数
 * 2. require.js AMD
 * 3. sea.js CMD
 * 4. node.js common.js
 * 6. es6 es module
 * 7  umd amd+cmd_common+es+module
 **/