console.log(1);
let load = require('./load');
console.log(2);