console.log('hello');
while (true) { };