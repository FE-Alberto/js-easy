1. 接着讲一下res.cookie的参数
2. 接着完善res.cookie的方法支持这些参数
3. 用 cookie实现权限认证
4. 基于cookie实现session原理
5. 使用express-session,了解它的参数的用法 。
6. 自己实现一个自定义session存储，session放在文件里。
7. 自动登录。